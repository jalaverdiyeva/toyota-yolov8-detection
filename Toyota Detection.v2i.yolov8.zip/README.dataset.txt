# Toyota Detection > 2025-12-01 9:44am
https://universe.roboflow.com/ada-12lh1/toyota-detection-whdkj

Provided by a Roboflow user
License: CC BY 4.0

